package SeleniumT;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Test {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		int cnt=0;
		
		driver.get("file:///C:/Users/HP/Downloads/traveler/index.html");
		driver.findElement(By.id("fullname")).sendKeys("snehal");
		Thread.sleep(2000);
		cnt++;
		
		
		Select activities = new Select(driver.findElement(By.id("activities")));
		activities.selectByVisibleText("Caving");
		Thread.sleep(2000);
		cnt++;
		
		Select destination = new Select(driver.findElement(By.id("destination")));
		destination.selectByVisibleText("Australia");
		Thread.sleep(2000);
		cnt++;
		
		WebElement selectDate = driver.findElement(By.id("date-start"));
	    //selectDate.click();
		selectDate.sendKeys("09/06/1999");
		Thread.sleep(2000);
		cnt++;
		
		driver.findElement(By.name("submit")).click();
		Thread.sleep(2000);
		cnt++;
		
		
		
		driver.findElement(By.linkText("Destination")).click();
	    Thread.sleep(3000);
	    cnt++;
	    
	   
	    
	    
	    driver.findElement(By.linkText("Travel")).click();
	    Thread.sleep(3000);
	    cnt++;
	    
	    driver.findElement(By.name("Aus")).click();
		Thread.sleep(2000);
		cnt++;
		
		 driver.findElement(By.linkText("Contact")).click();
		    Thread.sleep(3000);
		    cnt++;
		    
		    
		    driver.findElement(By.id("name")).sendKeys("snehal");
			Thread.sleep(2000);
			cnt++;
			
			driver.findElement(By.id("email")).sendKeys("sb123@gmail.com");
			Thread.sleep(2000);
			cnt++;
			
			driver.findElement(By.id("mobile")).sendKeys("9165262234");
			Thread.sleep(2000);
			cnt++;
			
			driver.findElement(By.name("submit2")).click();
			Thread.sleep(2000);
			cnt++;
		
		
	    
	    Thread.sleep(3000);
		driver.close();
		
		if(cnt==13)
		{
			System.out.println("Successfully Tested!!!");
		}
		
		
		
		
		
		
		
		
		/*
		driver.findElement(By.id("uname")).sendKeys("snehal");
		driver.findElement(By.id("password")).sendKeys("abcdef");
		driver.findElement(By.id("fname")).sendKeys("snehal");
		driver.findElement(By.id("lname")).sendKeys("mukhekar");
		
        
		WebElement female_gender = driver.findElement(By.xpath("//*[@name='gender'][@value='female']"));
		female_gender.click();
		System.out.println("gender female radio button selected state "+female_gender.isSelected());
		System.out.println("gender female radio button displayed state "+female_gender.isDisplayed());
		System.out.println("gender female radio button enabled state "+female_gender.isEnabled());
		
		WebElement select_clas = driver.findElement(By.name("des"));
		Select selc = new Select(select_clas);
		selc.selectByValue("3");
		
		WebElement sub_oop = driver.findElement(By.xpath("//*[@name='Remember'][@value='rem']"));
		sub_oop.click();
		System.out.println("subject oop checkbox selected state "+sub_oop.isSelected());
		System.out.println("subject oop checkbox displayed state "+sub_oop.isDisplayed());
		System.out.println("subject oop checkbox enabled state "+sub_oop.isEnabled());
		
		driver.findElement(By.id("bt1")).click();
		Alert alert = driver.switchTo().alert();
		String alertMessage = driver.switchTo().alert().getText();
		System.out.println(alertMessage);
		*/
		
	}

}
